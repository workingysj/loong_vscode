#include "widget.h"

#include <QtCharts>
QT_CHARTS_USE_NAMESPACE

#include "ui_widget.h"

#include <QModbusRtuSerialMaster>
#include <QModbusDataUnit>
#include <QModbusReply>

#include <QMessageBox>
#include <QVariant>
#include <QSerialPort>
#include <QDebug>

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonValue>
#include <QJsonParseError>

#include <QChartView>
#include <QSplineSeries>
#include <QDateTime>
#include <QDateTimeAxis>
#include <QValueAxis>

#include <QFont>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    this->setWindowTitle("智能城市检测系统");

    teminitChart();
    preinitChart();
    speinitChart();
    waterQualityChart();

    /*modbusDevic = new QModbusTcpClient(this);
    if(modbusDevic->state()!=QModbusDevice::ConnectedState)
    {
        modbusDevic->setConnectionParameter(QModbusDevice::NetworkPortParameter,9000);
        modbusDevic->setConnectionParameter(QModbusDevice::NetworkAddressParameter,"192.168.1.100");
        modbusDevic->connectDevice();

    }
    else
    {
        modbusDevic->disconnectDevice();
    }*/


    timer = new QTimer();
    connect(timer,&QTimer::timeout,this,&Widget::timerSLot);
    timer->start(1000);

    m_timer=new QTimer(this);
    m_timer->setInterval(1000);

    connect(m_timer,&QTimer::timeout,this,&Widget::on_timerTimeout);

    a_timer=new QTimer(this);
    a_timer->setInterval(3000);

    connect(a_timer,&QTimer::timeout,this,&Widget::on_timerupload);

    //QHostAddress m_address("iq0vkon4zrV.iot-as-mqtt.cn-shanghai.aliyuncs.com");
    //client = new QMQTT:Client(m_address, 1883);
    client = new QMqttClient;

    /*client->setHostname("iq0vkon4zrV.iot-as-mqtt.cn-shanghai.aliyuncs.com");
    //client->setHostName("iq0vkon4zrV.iot-as-mqtt.cn-shanghai.aliyuncs.com");

    client->setPort(1883);
    client->setUsername("YINGJIAN&iq0vkon4zrV");
    client->setPassword("71DFCF17A69B04ADC313877FADE96E3710907C2B");
    client->setClientId("YINGJIAN|securemode=3,signmethod=hmacsha1|");
    client->connectToHost();*/

    /*client->setHostname("k1gd7jxaNRT.iot-as-mqtt.cn-shanghai.aliyuncs.com");

    client->setPort(1883);
    client->setUsername("esp8266&k1gd7jxaNRT");
    client->setPassword("822595f497de61a50fa954ae52b782b052470d08");
    client->setClientId("esp8266|securemode=3,signmethod=hmacsha1|");
    client->connectToHost();*/


    client->setHostname("k1gd72Ovuzs.iot-as-mqtt.cn-shanghai.aliyuncs.com");

    client->setPort(1883);
    client->setUsername("2k1000la&k1gd72Ovuzs");
    client->setPassword("89d49ccf055f4eb1eaee4511684ac1d0834682d8");
    client->setClientId("2k1000la|securemode=3,signmethod=hmacsha1|");
    client->connectToHost();
    //QString sub="/iq0vkon4zrV/YINGJIAN/user/get";
    QString sub="/k1gd72Ovuzs/2k1000la/user/get";
    client->subscribe(sub);

    connect(client,&QMqttClient::connected,this,&Widget::connectSuccessSlot);
    //connect(client,SIGNAL(received(QMQTT::Message)),this,SLOT(recvMessageSlot(QMQTT::Message)));

    QSqlDatabase db=QSqlDatabase::addDatabase("QMYSQL");//加载MySQL数据库驱动
    db.setDatabaseName("mydatabase");
    db.setHostName("localhost");
    db.setUserName("root");
    db.setPassword("123456");
    db.open();
    /*QStringList drivers = QSqlDatabase::drivers();
        for(auto driver: drivers)
            qDebug() << driver;
        bool ok = db.open();
        if(ok)
        {
            QMessageBox::information(this, "提示","数据库连接成功");
            qDebug()<<"数据库连接成功";
        }
        else
        {
            QMessageBox::information(this, "提示","数据库连接失败");
            this->close();
            qDebug()<<"数据库连接失败"<<db.lastError().text();
        }*/



    m=new QSqlTableModel;
    m->setTable("modeldata");
    m->setHeaderData(0,Qt::Orientation::Horizontal,"更新时间");
    m->setHeaderData(1,Qt::Orientation::Horizontal,"气温");
    m->setHeaderData(2,Qt::Orientation::Horizontal,"湿度");
    m->setHeaderData(3,Qt::Orientation::Horizontal,"水位");
    m->setHeaderData(4,Qt::Orientation::Horizontal,"水质");
    m->removeColumn(5);
    m->removeColumn(5);
    m->removeColumn(5);
    m->removeColumn(5);
    m->removeColumn(5);
    ui->tableView->setModel(m);
    ui->tableView->setColumnWidth(0,200);
    ui->tableView->setColumnWidth(1,160);
    ui->tableView->setColumnWidth(2,160);
    ui->tableView->setColumnWidth(3,160);
    ui->tableView->setColumnWidth(4,188);

    ui->yearEdit->setText("2024");
//    ui->monthEdit->setText("8");


    QFont f;
    f.setPixelSize(20);
    ui->labelTime->setFont(f);

    //桥梁检测和光照强度隐藏
    ui->label_6->hide();
    ui->lightEdit->hide();
    ui->label_2->hide();
    ui->bridgeEdit->hide();

    //控制指令隐藏
    ui->groupBox_2->hide();

}

Widget::~Widget()
{


    delete ui;
}


void Widget::timerSLot()
{
    QDateTime time = QDateTime::currentDateTime();
    QString str = time.toString("yyyy-MM-dd hh:mm:ss");
    ui->labelTime->setText(str);
}

/*void Widget::temread()
{
    QModbusReply *temreply=(QModbusReply *)(sender());
    QModbusDataUnit temunit=temreply->result();

    temreply->deleteLater();
    if(temunit.valueCount()>0){
        ui->temEdit->setText(QString::number(temunit.value(0)));
     }

    QString topic="/iq0vkon4zrV/YINGJIAN/user/longxin";
    QString msg="{\"temperature\":";
            msg+=ui->temEdit->text();
            msg+="}";
    QByteArray ba=msg.toUtf8();
    //QMQTT::Message message(1,topic,ba);
    //client->publish(message);
    client->publish(topic,ba);
}

void Widget::preread()
{
    QModbusReply *prereply=(QModbusReply *)(sender());
    QModbusDataUnit preunit=prereply->result();

    prereply->deleteLater();

    if(preunit.valueCount()>0){

        ui->pressureEdit->setText(QString::number(preunit.value(0)));
     }

    QString topic="/iq0vkon4zrV/YINGJIAN/user/longxin";
    QString msg="{\"pressure\":";
            msg+=ui->pressureEdit->text();
            msg+="}";
    QByteArray ba=msg.toUtf8();
    //QMQTT::Message message(1,topic,ba);
    //client->publish(message);
    client->publish(topic,ba);
}
void Widget::on_readtemButton_clicked()
{
    QString topic="/iq0vkon4zrV/YINGJIAN/user/longxin";
    QString msg="{\"currenttemperature\":";
            msg+=ui->temEdit->text();
            msg+="}";
    QByteArray ba=msg.toUtf8();
    //QMQTT::Message message(1,topic,ba);
    //client->publish(message);
    client->publish(topic,ba);

    QModbusDataUnit readtemunit(QModbusDataUnit::HoldingRegisters,0,1);
    auto temreply = modbusDevic->sendReadRequest(readtemunit,1);
    if(temreply){
        if(!temreply->isFinished()){
            connect(temreply,&QModbusReply::finished,this,&Widget::temread);
            return;
        }
        temreply->deleteLater();
    }


}


void Widget::on_readpreButton_clicked()
{
    QModbusDataUnit readpreunit(QModbusDataUnit::HoldingRegisters,1,1);
    auto prereply = modbusDevic->sendReadRequest(readpreunit,1);
    if(prereply){
        if(!prereply->isFinished()){
            connect(prereply,&QModbusReply::finished,this,&Widget::preread);
            return;
        }
        prereply->deleteLater();
    }


}

void Widget::readyread()
{
    QModbusReply *reply=(QModbusReply *)(sender());
    if (!reply){
        return ;
    }
    QModbusDataUnit unit=reply->result();

    vector.append(unit.value(0));

    ui->temEdit->setText(QString::number(unit.value(0)));
    ui->pressureEdit->setText(QString::number(unit.value(1)));
    ui->doorEdit->setText(QString::number(unit.value(6)));
    ui->floorEdit->setText(QString::number(unit.value(7)));
    ui->faultEdit->setText(QString::number(unit.value(8)));
    ui->humEdit->setText(QString::number(unit.value(10)));

    // 更新X轴的范围
    chart1->axisX()->setMin(QDateTime::currentDateTime().addSecs(-1*10));
    chart1->axisX()->setMax(QDateTime::currentDateTime().addSecs(0));
    //在线上添加点
    series1->append(QDateTime::currentDateTime().toMSecsSinceEpoch(),  ui->temEdit->text().toInt());

    chart2->axisX()->setMin(QDateTime::currentDateTime().addSecs(-1*10));
    chart2->axisX()->setMax(QDateTime::currentDateTime().addSecs(0));

    series2->append(QDateTime::currentDateTime().toMSecsSinceEpoch(), ui->pressureEdit->text().toInt());

    chart3->axisX()->setMin(QDateTime::currentDateTime().addSecs(-1*10));
    chart3->axisX()->setMax(QDateTime::currentDateTime().addSecs(0));

    series3->append(QDateTime::currentDateTime().toMSecsSinceEpoch(), ui->humEdit->text().toInt());

    QString topic="/iq0vkon4zrV/YINGJIAN/user/longxin";
    QString msg="{\"temperature\":";
            msg+=ui->temEdit->text();
            msg+=",\"pressure\":";
            msg+=ui->pressureEdit->text();
            msg+=",\"floor\":";
            msg+=ui->floorEdit->text();
            msg+=",\"open\":";
            msg+=ui->doorEdit->text();
            msg+=",\"malfunction\":";
            msg+=ui->faultEdit->text();
            msg+=",\"humidity\":";
            msg+=ui->humEdit->text();
            msg+="}";
    QByteArray ba=msg.toUtf8();
    //QMQTT::Message message(6,topic,ba);
    //client->publish(message);
    client->publish(topic,ba);

    vector.clear();

    reply->deleteLater();

}*/

void Widget::on_timebtnRead_clicked()
{
    m_timer->start();
}

void Widget::on_timerTimeout()
{
/*    chart1->axisX()->setMin(QDateTime::currentDateTime().addSecs(-1*10));
    chart1->axisX()->setMax(QDateTime::currentDateTime().addSecs(0));
    //在线上添加点
    series1->append(QDateTime::currentDateTime().toMSecsSinceEpoch(), rand()%20);
*/
    /*QModbusDataUnit readunit(QModbusDataUnit::HoldingRegisters,0,11);
    QModbusReply *reply = modbusDevic->sendReadRequest(readunit,1);
    if(reply){
        if(!reply->isFinished()){
            connect(reply,&QModbusReply::finished,this,&Widget::readyread);
            return;
        }
        reply->deleteLater();

    }*/

    // 更新X轴的范围
    chart1->axisX()->setMin(QDateTime::currentDateTime().addSecs(-1*10));
    chart1->axisX()->setMax(QDateTime::currentDateTime().addSecs(0));
    //在线上添加点
    series1->append(QDateTime::currentDateTime().toMSecsSinceEpoch(),  ui->temEdit->text().toInt());

    chart2->axisX()->setMin(QDateTime::currentDateTime().addSecs(-1*10));
    chart2->axisX()->setMax(QDateTime::currentDateTime().addSecs(0));

    series2->append(QDateTime::currentDateTime().toMSecsSinceEpoch(), ui->humEdit->text().toInt());

    chart3->axisX()->setMin(QDateTime::currentDateTime().addSecs(-1*10));
    chart3->axisX()->setMax(QDateTime::currentDateTime().addSecs(0));

    series3->append(QDateTime::currentDateTime().toMSecsSinceEpoch(), ui->levelEdit->text().toInt());

    chart4->axisX()->setMin(QDateTime::currentDateTime().addSecs(-1*10));
    chart4->axisX()->setMax(QDateTime::currentDateTime().addSecs(0));
    series4->append(QDateTime::currentDateTime().toMSecsSinceEpoch(), ui->qualityEdit->text().toUInt());

}

void Widget::on_stopreadButton_clicked()
{
    m_timer->stop();
}

/*void Widget::on_connectmodelButton_clicked()
{

    if(!modbusDevic->connectDevice())
    {
        QMessageBox::warning(this,"报告","连接失败");
    }
    else
    {
        QMessageBox::information(this,"报告","连接成功");

    }
}*/


/*void Widget::on_writefloorButton_clicked()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,2,1);
    writeunit.setValue(0,ui->controlfloorEdit->text().toUInt());
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }
}

void Widget::on_readfloorButton_clicked()
{
    QModbusDataUnit readdoorunit(QModbusDataUnit::HoldingRegisters,7,1);
    QModbusReply *doorreply = modbusDevic->sendReadRequest(readdoorunit,1);
    if(doorreply){
        if(!doorreply->isFinished()){
            connect(doorreply,&QModbusReply::finished,this,&Widget::Readfloor);

            return;
        }

        doorreply->deleteLater();
    }

}

void Widget::Readfloor()
{
    QModbusReply *reply=(QModbusReply *)(sender());
    QModbusDataUnit unit=reply->result();
    reply->deleteLater();

    if(unit.valueCount()>0){
        ui->floorEdit->setText(QString::number(unit.value(0)));
        QString topic="/iq0vkon4zrV/YINGJIAN/user/longxin";
        QString msg="{\"open\":";
                msg+=ui->floorEdit->text();
                msg+="}";
        QByteArray ba=msg.toUtf8();
        //QMQTT::Message message(1,topic,ba);
        //client->publish(message);
        client->publish(topic,ba);
     }

}

void Widget::on_updownButton_clicked()
{
    if(flag_updown)
       {
           emit startcontrol();
           this->flag_updown=false;
           ui->updownButton->setText("是");
           ui->updownEdit->setText("1");
       }
       else {
           emit stopcontrol();
           this->flag_updown=true;
           ui->updownButton->setText("否");
           ui->updownEdit->setText("0");
       }
}
void Widget::startcontrol()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,3,1);
    writeunit.setValue(0,1);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }
}

void Widget::stopcontrol()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,3,1);
    writeunit.setValue(0,0);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }
}


void Widget::on_opendoorButton_clicked()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,5,1);
    writeunit.setValue(0,1);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }

    ui->controldoorEdit->setText("1");

}

void Widget::on_closedoorButton_clicked()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,5,1);
    writeunit.setValue(0,2);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }

    ui->controldoorEdit->setText("2");

}

void Widget::on_stopdoorButton_clicked()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,5,1);
    writeunit.setValue(0,3);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }

    ui->controldoorEdit->setText("3");

}

void Widget::on_upButton_clicked()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,4,1);
    writeunit.setValue(0,1);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }

    ui->updowncontrolEdit->setText("1");
}

void Widget::on_downButton_clicked()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,4,1);
    writeunit.setValue(0,2);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }

    ui->updowncontrolEdit->setText("2");
}

void Widget::on_stopButton_clicked()
{
    QModbusDataUnit writeunit(QModbusDataUnit::HoldingRegisters,4,1);
    writeunit.setValue(0,0);
    QModbusReply *reply = modbusDevic->sendWriteRequest(writeunit,1);
    if(reply){

        reply->deleteLater();
    }

    ui->updowncontrolEdit->setText("0");
}

void Widget::on_readdoorButton_clicked()
{
    QModbusDataUnit readunit(QModbusDataUnit::HoldingRegisters,6,1);
    QModbusReply *reply = modbusDevic->sendReadRequest(readunit,1);
    if(reply){
        if(!reply->isFinished()){
            connect(reply,&QModbusReply::finished,this,&Widget::Readdoor);

            return;
        }

        reply->deleteLater();
    }


}

void Widget::Readdoor()
{
    QModbusReply *reply=(QModbusReply *)(sender());
    QModbusDataUnit unit=reply->result();
    reply->deleteLater();

    if(unit.valueCount()>0){
        ui->doorEdit->setText(QString::number(unit.value(0)));
        QString topic="/iq0vkon4zrV/YINGJIAN/user/longxin";
        QString msg="{\"open\":";
                msg+=ui->doorEdit->text();
                msg+="}";
        QByteArray ba=msg.toUtf8();
        //QMQTT::Message message(1,topic,ba);
        //client->publish(message);
        client->publish(topic,ba);
     }

}

void Widget::on_readfaultButton_clicked()
{
    QModbusDataUnit readunit(QModbusDataUnit::HoldingRegisters,8,1);
    QModbusReply *reply = modbusDevic->sendReadRequest(readunit,1);
    if(reply){
        if(!reply->isFinished()){
            connect(reply,&QModbusReply::finished,this,&Widget::Readfault);

            return;
        }

        reply->deleteLater();
    }
}

void Widget::Readfault()
{
    QModbusReply *reply=(QModbusReply *)(sender());
    QModbusDataUnit unit=reply->result();
    reply->deleteLater();

    if(unit.valueCount()>0){
        ui->faultEdit->setText(QString::number(unit.value(0)));
        QString topic="/iq0vkon4zrV/YINGJIAN/user/longxin";
        QString msg="{\"malfunction\":";
                msg+=ui->faultEdit->text();
                msg+="}";
        QByteArray ba=msg.toUtf8();
        //QMQTT::Message message(1,topic,ba);
        //client->publish(message);
        client->publish(topic,ba);
     }
}

void Widget::on_readspeedButton_clicked()
{
    QModbusDataUnit readunit(QModbusDataUnit::HoldingRegisters,10,1);
    QModbusReply *reply = modbusDevic->sendReadRequest(readunit,1);
    if(reply){
        if(!reply->isFinished()){
            connect(reply,&QModbusReply::finished,this,&Widget::Readspeed);

            return;
        }

        reply->deleteLater();
    }
}

void Widget::Readspeed()
{
    QModbusReply *reply=(QModbusReply *)(sender());
    QModbusDataUnit unit=reply->result();
    reply->deleteLater();

    if(unit.valueCount()>0){
        ui->humEdit->setText(QString::number(unit.value(0)));
        QString topic="/iq0vkon4zrV/YINGJIAN/user/longxin";
        QString msg="{\"humidity\":";
                msg+=ui->humEdit->text();
                msg+="}";
        QByteArray ba=msg.toUtf8();
        //QMQTT::Message message(1,topic,ba);
        //client->publish(message);
        client->publish(topic,ba);
     }
}*/

void Widget::on_connectserverButton_clicked()
{
    client->connectToHost();
}
void Widget::connectSuccessSlot()
{
    QMessageBox::information(this,"连接提示","阿里云连接成功");

    connect(client,&QMqttClient::messageReceived,this,&Widget::recvMessageSlot);
    connect(client,&QMqttClient::disconnected,[this]()
    {
        QMessageBox::warning(this,"连接提示","服务器断开");
    });
}

void Widget::recvMessageSlot(const QByteArray &message)
{
    QByteArray pay_load=message;
    ui->textEdit->setText(QString(pay_load));

    QString json_str=ui->textEdit->text();

    QJsonParseError jsonError;
    QJsonDocument doc = QJsonDocument::fromJson(pay_load, &jsonError);

    if (doc.isObject()) {
            QJsonObject object = doc.object();  // 转化为对象

            QJsonObject itemsobject = object.value("items").toObject();


            QJsonObject temobject = itemsobject.value("temperature").toObject();
            if(!temobject.isEmpty()){
                QJsonValue value = temobject.value("value");
                double data= value.toDouble();
                QString num=QString::number(data);
                ui->temEdit->setText(num);
            }
            QJsonObject humobject = itemsobject.value("Humidity").toObject();
            if(!humobject.isEmpty()){
                QJsonValue value = humobject.value("value");
                double data= value.toDouble();
                QString num=QString::number(data);
                ui->humEdit->setText(num);
            }
            QJsonObject levelobject = itemsobject.value("WaterLevel").toObject();
            if(!levelobject.isEmpty()){
                QJsonValue value = levelobject.value("value");
                double data= value.toDouble();
                QString num=QString::number(data);
                ui->levelEdit->setText(num);
            }
            QJsonObject qualityobject = itemsobject.value("watertype").toObject();
            if(!qualityobject.isEmpty()){
                QJsonValue value = qualityobject.value("value");
                double data= value.toDouble();
                QString num=QString::number(data);
                ui->qualityEdit->setText(num);
            }


    }

}


/*void Widget::on_uploadButton_clicked()
{
    QString sql=QString("insert into modeldata values('%1','%2','%3','%4','%5','%6','%7','%8','%9','%10');").arg(ui->labelTime->text()).arg(ui->temEdit->text()).arg(ui->pressureEdit->text()).arg(ui->floorEdit->text()).arg(ui->doorEdit->text()).arg(ui->faultEdit->text()).arg(ui->updownEdit->text()).arg(ui->updowncontrolEdit->text()).arg(ui->controldoorEdit->text()).arg(ui->controlfloorEdit->text());

    QSqlQuery query;
    if(query.exec(sql))
    {
        QMessageBox::information(this,"上传提示","上传成功");
    }
    else
    {
        QMessageBox::warning(this,"上传提示","上传失败");
    }
    m->select();
}*/

void Widget::on_timeuploadButton_clicked()
{
    a_timer->start();
}

void Widget::on_timerupload()
{
    QString sql=QString("insert into modeldata values('%1','%2','%3','%4','%5','%6','%7','%8','%9','%10');").arg(ui->labelTime->text()).arg(ui->temEdit->text()).arg(ui->humEdit->text()).arg(ui->levelEdit->text()).arg(ui->qualityEdit->text()).arg(ui->lightEdit->text()).arg(ui->bridgeEdit->text()).arg(ui->updownEdit->text()).arg(ui->controlfloorEdit->text()).arg(ui->updowncontrolEdit->text());
    QSqlQuery query;
    query.exec(sql);
    m->select();
}

void Widget::on_stopuploadButton_clicked()
{
    a_timer->stop();
}

/*void Widget::on_connectmysqlButton_clicked()
{


}*/

/*void Widget::on_clearButton_clicked()
{
    QSqlQuery query;
    query.exec("delete from modeldata;");
    m->select();
}*/


void Widget::on_findButton_clicked()
{
    QString start=""+ui->yearEdit->text()+"-0"+ui->monthEdit->text()+"-0"+ui->dayEdit->text()+" 00:00:00";
    QString end=""+ui->yearEdit->text()+"-0"+ui->monthEdit->text()+"-0"+ui->dayEdit->text()+" 23:59:59";
    QString str=QString("uploadtime >'%1' and uploadtime <'%2'").arg(start).arg(end);

    m->setFilter(str);
    m->select();

    QSqlQuery query;
    int n=0;
    query.exec("select *from modeldata where "+str+" order by uploadtime desc;");
    query.first();
    QDateTime data=query.value(0).toDateTime();
    double tem=query.value(1).toDouble();
    double pre=query.value(2).toDouble();
    double spe=query.value(3).toDouble();
    double qua=query.value(4).toDouble();

    chart1->axisX()->setMin(data.addSecs(-1*10));
    chart1->axisX()->setMax(data.addSecs(0));

    chart2->axisX()->setMin(data.addSecs(-1*10));
    chart2->axisX()->setMax(data.addSecs(0));

    chart3->axisX()->setMin(data.addSecs(-1*10));
    chart3->axisX()->setMax(data.addSecs(0));

    chart4->axisX()->setMin(data.addSecs(-1*10));
    chart4->axisX()->setMax(data.addSecs(0));

    series1->append(data.toMSecsSinceEpoch(), tem);

    series2->append(data.toMSecsSinceEpoch(), pre);

    series3->append(data.toMSecsSinceEpoch(), spe);

    series4->append(data.toMSecsSinceEpoch(), qua);

    while(query.next()&&n<15)
    {
        data=query.value(0).toDateTime();
        tem=query.value(1).toDouble();
        pre=query.value(2).toDouble();
        spe=query.value(3).toDouble();

        series1->append(data.toMSecsSinceEpoch(), tem);


        series2->append(data.toMSecsSinceEpoch(), pre);


        series3->append(data.toMSecsSinceEpoch(), spe);


        series4->append(data.toMSecsSinceEpoch(), qua);

        n++;
    }



}

void Widget::teminitChart()
{
    series1 = new QLineSeries();         // 创建一个折线图series
    series1->setName("温度");
    series1->setColor(QColor(255,0,0));

    chart1 = ui->temchartView->chart();     // 获取QchartView内置的chart
    chart1->addSeries(series1);   // 将创建好的折线图series添加进chart中

    //声明并初始化X轴、两个Y轴
    QDateTimeAxis *axisX = new QDateTimeAxis();//x轴为时间轴
    QValueAxis *axisY = new QValueAxis();
    //设置x坐标轴

    // 隐藏背景网格X轴框线
    //axisX->setGridLineVisible(false);
    // x轴显示的文字倾斜角度
    axisX->setLabelsAngle(0);
    // 轴上点的个数
    axisX->setTickCount(10);
    axisX->setFormat("mm:ss");

    //设置y坐标轴上的格点
    axisY->setTickCount(7);
    axisY->setMin(20);
    axisY->setMax(40);
    //设置坐标轴显示的名称
    QFont font("Microsoft YaHei",8,QFont::Normal);//微软雅黑。字体大小8
    axisX->setTitleFont(font);
    axisY->setTitleFont(font);
    //axisX->setTitleText("时间");
    //axisY->setTitleText("温度");
    //设置网格不显示
    //axisY->setGridLineVisible(false);

    chart1->setAxisX(axisX,series1);
    chart1->setAxisY(axisY,series1);

    ui->temchartView->setChart(chart1);
    //chart->createDefaultAxes();                 // 基于已添加到图表中的series为图表创建轴。以前添加到图表中的任何轴都将被删除。
    //chart->setTitle("电梯内温度");            // 设置标题

    ui->temchartView->setRenderHint(QPainter::Antialiasing);  // 设置抗锯齿
}

void Widget::preinitChart()
{
    series2 = new QLineSeries();         // 创建一个折线图series
    series2->setName("湿度");
    series2->setColor(QColor(0,0,255));

    chart2 = ui->prechartView->chart();     // 获取QchartView内置的chart
    chart2->addSeries(series2);                   // 将创建好的折线图series添加进chart中
    //声明并初始化X轴、两个Y轴
    QDateTimeAxis *axisX = new QDateTimeAxis();//x轴为时间轴
    QValueAxis *axisY = new QValueAxis();
    //设置x坐标轴

    // 隐藏背景网格X轴框线
    //axisX->setGridLineVisible(false);
    // x轴显示的文字倾斜角度
    axisX->setLabelsAngle(0);
    // 轴上点的个数
    axisX->setTickCount(10);
    axisX->setFormat("mm:ss");

    //设置y坐标轴上的格点
    axisY->setTickCount(7);
    axisY->setMin(0);
    axisY->setMax(100);
    //设置坐标轴显示的名称
    QFont font("Microsoft YaHei",8,QFont::Normal);//微软雅黑。字体大小8
    axisX->setTitleFont(font);
    axisY->setTitleFont(font);
    //axisX->setTitleText("时间");
    //axisY->setTitleText("压力");
    //设置网格不显示
    //axisY->setGridLineVisible(false);

    chart2->setAxisX(axisX,series2);
    chart2->setAxisY(axisY,series2);

    ui->prechartView->setChart(chart2);
    //chart->createDefaultAxes();                 // 基于已添加到图表中的series为图表创建轴。以前添加到图表中的任何轴都将被删除。
    //chart->setTitle("电梯内压力");            // 设置标题

    ui->prechartView->setRenderHint(QPainter::Antialiasing);  // 设置抗锯齿
}

void Widget::speinitChart()
{
    series3 = new QLineSeries();         // 创建一个折线图series
    series3->setName("液位");
    series3->setColor(QColor(38,162,105));

    chart3 = ui->spechartView->chart();     // 获取QchartView内置的chart
    chart3->addSeries(series3);                   // 将创建好的折线图series添加进chart中
    //声明并初始化X轴、两个Y轴
    QDateTimeAxis *axisX = new QDateTimeAxis();//x轴为时间轴
    QValueAxis *axisY = new QValueAxis();
    //设置x坐标轴

    // 隐藏背景网格X轴框线
    //axisX->setGridLineVisible(false);
    // x轴显示的文字倾斜角度
    axisX->setLabelsAngle(0);
    // 轴上点的个数
    axisX->setTickCount(5);
    axisX->setFormat("mm:ss");

    //设置y坐标轴上的格点
    axisY->setTickCount(5);
    axisY->setMin(0);
    axisY->setMax(10);
    //设置坐标轴显示的名称
    QFont font("Microsoft YaHei",8,QFont::Normal);//微软雅黑。字体大小8
    axisX->setTitleFont(font);
    axisY->setTitleFont(font);
    //axisX->setTitleText("时间");
    //axisY->setTitleText("速度");
    //设置网格不显示
    //axisY->setGridLineVisible(false);

    chart3->setAxisX(axisX,series3);
    chart3->setAxisY(axisY,series3);

    ui->spechartView->setChart(chart3);
    //chart->createDefaultAxes();                 // 基于已添加到图表中的series为图表创建轴。以前添加到图表中的任何轴都将被删除。
    //chart->setTitle("电梯运行速度");            // 设置标题

    ui->spechartView->setRenderHint(QPainter::Antialiasing);  // 设置抗锯齿
}

void Widget::waterQualityChart()
{
    series4 = new QLineSeries();         // 创建一个折线图series
    series4->setName("水质检测");
    series4->setColor(QColor(38,162,105));

    chart4 = ui->spechartView_2->chart();     // 获取QchartView内置的chart
    chart4->addSeries(series4);                   // 将创建好的折线图series添加进chart中
    //声明并初始化X轴、两个Y轴
    QDateTimeAxis *axisX = new QDateTimeAxis();//x轴为时间轴
    QValueAxis *axisY = new QValueAxis();
    //设置x坐标轴

    // 隐藏背景网格X轴框线
    //axisX->setGridLineVisible(false);
    // x轴显示的文字倾斜角度
    axisX->setLabelsAngle(0);
    // 轴上点的个数
    axisX->setTickCount(10);
    axisX->setFormat("mm:ss");

    //设置y坐标轴上的格点
    axisY->setTickCount(6);
    axisY->setMin(0);
    axisY->setMax(150);
    //设置坐标轴显示的名称
    QFont font("Microsoft YaHei",8,QFont::Normal);//微软雅黑。字体大小8
    axisX->setTitleFont(font);
    axisY->setTitleFont(font);
    //axisX->setTitleText("时间");
    //axisY->setTitleText("速度");
    //设置网格不显示
    //axisY->setGridLineVisible(false);

    chart4->setAxisX(axisX,series4);
    chart4->setAxisY(axisY,series4);

    ui->spechartView_2->setChart(chart4);
    //chart->createDefaultAxes();                 // 基于已添加到图表中的series为图表创建轴。以前添加到图表中的任何轴都将被删除。
    //chart->setTitle("电梯运行速度");            // 设置标题

    ui->spechartView_2->setRenderHint(QPainter::Antialiasing);  // 设置抗锯齿
}



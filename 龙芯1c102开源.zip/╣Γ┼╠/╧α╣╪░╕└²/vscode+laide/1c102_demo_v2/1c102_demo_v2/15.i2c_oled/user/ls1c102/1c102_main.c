/*
    i2c-oled接线
    //  VCC     接 3.3v 电源
    //  GND     电源地
    //  SCL     GPIO4 （时钟）
    //  SDA     GPIO5 （数据）
    注意：i2c显示有关内容占两行，y=0,2,4,6
*/
#include "ls1x.h"
#include "Config.h"
#include "oled96.h"
#include "ls1c102_i2c.h"
#include "ls1x_latimer.h"
#include "ls1x_gpio.h"


int main(int arg, char *args[])
{
    gpio_pin_remap(GPIO_PIN_4,GPIO_FUNC_MAIN);//引脚复用4：scl
    gpio_pin_remap(GPIO_PIN_5,GPIO_FUNC_MAIN);//引脚复用5：sda

    I2C_InitTypeDef I2C_InitStruct0;
    I2C_StructInit(&I2C_InitStruct0);

    I2C_Init(I2C, &I2C_InitStruct0);
    delay_ms(100);
    OLED_Init();// 初始化 OLED 模块
    OLED_Full();// OLED全屏变白
    OLED_Clear();// OLED 清屏（整个屏幕填充黑色）

    while(1)
    {

        // 显示字符 16 * 8   chr： 示例：'A'       查看:oledfont.h 常用 ASCII 表是否有对应的字符
        OLED_ShowChar(0, 0, 'A');
        delay_ms(1000);
        OLED_Clear();

        // 显示字符串        *chr：示例："hello"   查看:oledfont.h 常用 ASCII 表是否有对应的字符
        OLED_ShowString(0, 2, "hello");
        delay_ms(1000);
        OLED_Clear();

        // 显示数字 num : 数值(0~4294967295); len : 数字的位数  size: 填写16
        OLED_ShowNum(0, 4, 1234567, 7, 16);
        delay_ms(1000);
        OLED_Clear();

        // 显示汉字 16*16  num :oledfont.h   SPI_Chi_Cha_Font_16x16中对应数字  可以自行添加需要的汉字
        OLED_ShowCHinese(0, 6, 0);
        OLED_ShowCHinese(16, 6, 1);
        OLED_ShowCHinese(32, 6, 2);
        OLED_ShowCHinese(48, 6, 3);
        delay_ms(1000);
        OLED_Clear();// 清屏（全黑）


    }
    return 0;
}


/*
   舵机控制信号为周期20ms的脉宽调制，本实验设置定时器为100us
   对于本次实验舵机控制： 高电平  0.5ms 0°    定时器计数5
                                  1.0ms 45°   定时器计数10
                                  1.5ms 90°   定时器计数15
                                  2.0ms 135°  定时器计数20
                                  2.5ms 180°  定时器计数25
*/
#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_ptimer.h"
extern int duty;
bool flag=0;
int main(int arg, char *args[])
{

    int i=0;
    timer_init(100); //set time 0.1ms
    duty=5;//初始设置0度
    delay_ms(1000);
    duty=10;//初始设置45度
    delay_ms(1000);
    duty=15;//初始设置90度
    delay_ms(1000);
    duty=20;//初始设置135度
    delay_ms(1000);
    duty=25;//初始设置180度
    delay_ms(1000);
    while(i<=2)
    {
        
        if(duty<25&&flag==0)
        {
            duty++;
            delay_ms(30);
        }
        if(duty>=25)
        {
            
            flag=1;
        }

        if(flag==1&&duty>5)
        {
            duty--;
            delay_ms(30);
        }
        if(duty==5)
        {
            flag=0;
            i++;
        }
     
    }
    return 0;
}

#ifndef _STEP_MOTOR_H
#define _STEP_MOTOR_H


#include "ls1x.h"




int round(int num, int num1);// 自定义四舍五入函数
void BYJ_gpio_write(unsigned char code);// 步进电机将二进制码转化为GPIO输出
void BYJ_gpio_stop(void);// 步进电机将二进制码转化为GPIO输出
void BYJ_run_angle(int p_degree, int p_dir, int p_step, long p_freq);// 控制步进电机输出角度，单位°。
void BYJ_run_step(int p_count_step, int p_dir, int p_step, long p_freq);// 控制步进电机输出步数（拍数）。


#endif // _STEP_MOTOR_H

/*
  步进电机实验,四拍转动频率应低于八拍转动频率
*/
#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_ptimer.h"
#include "step_motor.h"
extern uint32_t freq;
int main(int arg, char *args[])
{
    AFIO_RemapConfig(AFIOC, GPIO_Pin_6 | GPIO_Pin_7, 0);
    BYJ_run_angle(90, 0, 4, 500);//四拍90°
    // BYJ_run_angle(90, 0, 8, 1000);//8拍90°
    timer_init(freq); 

    return 0;
}


#include "ls1x.h"
#include "Config.h"
#include "queue.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1x_string.h"
#include "ls1c102_interrupt.h"
#include "queue.h"
#define LED 20

uint8_t Read_Buffer[DATA_LEN];//设置接收缓冲数组
uint8_t Read_length;
int main(int arg, char *args[])
{
    while(1)
    {
        if(Queue_isEmpty(&Circular_queue)==0)//判断队列是否为空，即判断是否收到数据
        {
            Read_length=Queue_HadUse(&Circular_queue);//返回队列中数据的长度
            memset(Read_Buffer, 0, DATA_LEN);//填充接收缓冲区为0
            Queue_Read(&Circular_queue, Read_Buffer,Read_length);//读取队列缓冲区的值到接收缓冲区
            Read_Buffer[Read_length]='\0';//字符串接收结束符
            /*
               gpio_13外接LED灯
               判断收到字符为 ON  点灯
               判断收到字符为 OFF 关灯
            */
            if(strncmp(Read_Buffer,"ON",2)==0)
            {
                gpio_write_pin(LED,1);
            }
            if(strncmp(Read_Buffer,"OFF",3)==0)
            {
                gpio_write_pin(LED,0);
            }
        }
        delay_ms(1000);//处理数据时间大于发送数据，限制循环执行速率
    }

    return 0;
}
